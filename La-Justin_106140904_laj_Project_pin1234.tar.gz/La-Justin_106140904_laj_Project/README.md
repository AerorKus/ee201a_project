enter util value
source project.csh util
example: source project.csh 0.5

script will generate output.yaml

https://github.com/AerorKus/ee201a_project.git