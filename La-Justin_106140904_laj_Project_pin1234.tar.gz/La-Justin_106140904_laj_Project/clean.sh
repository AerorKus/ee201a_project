#!/bin/bash

rm -rf fv
rm -rf Lastname*
rm *.log
rm *.o
rm *.cmd
rm *.cmd*
rm *.log*
rm streamOut.map
rm -rf timingReports
rm -rf output
rm design_file
rm .*.rs.fp
rm .*.rs.fp.spr
