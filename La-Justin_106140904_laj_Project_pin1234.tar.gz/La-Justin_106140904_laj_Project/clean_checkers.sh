#!/bin/bash

rm -rf fv
rm *.o
rm *.cmd*
rm *.log*
rm -rf checker_output
rm -rf combined_checker_output.txt